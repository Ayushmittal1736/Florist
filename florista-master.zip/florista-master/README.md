# florista
A django web app backed by a CNN to classify images of flowers.
