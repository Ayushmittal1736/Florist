from django.apps import AppConfig


class IdentifyConfig(AppConfig):
    name = 'identify'
